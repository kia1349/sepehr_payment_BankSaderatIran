package com.sepehrpayment.ipg.constant;


/**
 * ConstantValues contains some constant variables, used all over the App.
 **/


public class ConstantValues {

    public static final String ECOMMERCE_URL = "http://www.aryaclub.com/";
    public static boolean IS_USER_PAID_SEPEHRPAY = false;
    public static String MESSAGE_USER_PAID_SEPEHRPAY = "";
    public static String MESSAGE_USER_PAID_SEPEHRPAY_WEB_VIEW = "";
    public static String SEPEHRPAY_PUBLISHABLE_KEY = "61000063";
    public static String LANGUAGE_DIRECTION = "rtl";

}
